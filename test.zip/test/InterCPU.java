/**
 * 
 */
package test;

/**
 * @author kigak-ka
 *
 */
public class InterCPU implements cpu {

	private int points = 0;
	
	public InterCPU (int points) {
		this.points = points;
	}
	/* (非 Javadoc)
	 * @see test.cpu#calculate()
	 */
	@Override
	public void calculate() {
		// TODO 自動生成されたメソッド・スタブ
		System.out.println("Inter CPU的针脚数为：" + points);
	}

}
