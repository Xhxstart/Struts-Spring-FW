/**
 * 
 */
package test;

/**
 * @author kigak-ka
 *
 */
public interface Mainboard {
	public void installCPU();
}
