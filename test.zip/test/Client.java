package test;

public class Client {

	public static void main(String[] args) {
		// TODO 自動生成されたメソッド・スタブ
		 ComputerEngineer cf = new ComputerEngineer();  
	        cf.makeComputer(1,1); 
	}

}
