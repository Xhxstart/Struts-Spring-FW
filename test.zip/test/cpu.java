/**
 * 
 */
package test;

/**
 * @author kigak-ka
 *
 */
public interface cpu {
   public void calculate();
}
