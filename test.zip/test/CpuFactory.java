/**
 * 
 */
package test;

/**
 * @author kigak-ka
 *
 */
public class CpuFactory {
	/**
	 * 组装CPU
	 * @param type CPU型号
	 * @return CPU
	 */
	public static cpu createCpu(int type) {
		cpu Cpu = null;
        if(type == 1){
        	Cpu = new InterCPU(755);
        }else if(type == 2){
        	Cpu = new AmdCPU(938);
        }
        return Cpu;
	}
}
