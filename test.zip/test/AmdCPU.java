/**
 * 
 */
package test;

/**
 * @author kigak-ka
 *
 */
public class AmdCPU implements cpu {
	
	private int points = 0;
	
	public AmdCPU (int points) {
		
	}

	/* (非 Javadoc)
	 * @see test.cpu#calculate()
	 */
	@Override
	public void calculate() {
		// TODO 自動生成されたメソッド・スタブ
		System.out.println("AMD CPU的针脚数：" + points);
	}

}
